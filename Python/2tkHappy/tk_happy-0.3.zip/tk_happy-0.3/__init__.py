#!/usr/bin/env python
# tk_happy main window

import main_window
